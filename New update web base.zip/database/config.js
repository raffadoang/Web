module.exports = {
  tokens: "8338831364:AAHqJxG1goGD6TKhAlq-fVemDednJcRylIQ",  // Ubah Jadi Token Bot Mu !!!
  owner: "7923609901", // Ubah Jadi Id Mu !!!
  port: "4146", // Ubah Jadi Port Panel Mu !!!
  ipvps: "https://sanzope.storexyz.web.id" // Ubah Jadi Ip Vps Mu !!!
};